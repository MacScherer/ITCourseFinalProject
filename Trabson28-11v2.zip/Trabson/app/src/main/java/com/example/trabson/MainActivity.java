package com.example.trabson;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
   EditText campoEmail;
   EditText campoNome;
   Button btnStart; //Chamando botao

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnStart = (Button) findViewById(R.id.botaoStart); //Construindo botao
        campoEmail = (EditText)findViewById(R.id.campoTextEmail);
        campoNome = (EditText)findViewById(R.id.campoTextNome);
    }

    public  void verificaInfo(View v) {

        if (!campoEmail.getText().toString().equals("")){ // Negando a condição de vazio
            if (!campoNome.getText().toString().equals("")) {
                //Toast.makeText(this, "Campos Cheios", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(this, Main2Activity.class); //Chama a tela
                        String paramNickname = campoNome.getText().toString();
                        intent.putExtra("nomeInstanciado", paramNickname);
                        startActivity(intent); //Constroi a tela
            }else{
                Toast.makeText(this, "Nome vazio, insira seu nick", Toast.LENGTH_LONG).show();
            }
        }else { // Confirmando que está vazio
            Toast.makeText(this, "Email vazio, insira seu email", Toast.LENGTH_LONG).show();
        }
    }


}

