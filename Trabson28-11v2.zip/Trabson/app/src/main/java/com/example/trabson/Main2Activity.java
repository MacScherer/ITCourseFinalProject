package com.example.trabson;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Bundle;
import android.widget.TextView;
import android.app.Activity;
import android.content.Context;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;
import android.widget.ListView;
import android.widget.ArrayAdapter ;
import java.util.ArrayList;


public class Main2Activity extends AppCompatActivity {
    TextView nickname;
    TextView score;
    TextView questao;

    String quest;
    String certa;
    String errada1;
    String errada2;
    String errada3;


    Button btnResposta1;
    Button btnResposta2;
    Button btnResposta3;
    Button btnResposta4;

    String url = "https://raw.githubusercontent.com/Evandro-Rodrigues/cepru/master/vinicius.json";
    String questaoLista;
    private ArrayList<String> listaQuestoes = new ArrayList<String>();
    private Context mContext;
    private Activity mActivity;

    int valorScore = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        String paramNome = this.getIntent().getStringExtra("nomeInstanciado");
        /*-------------------------------------------------------------------------------------------*/
        nickname = (TextView)findViewById(R.id.txtNickname);
        score = (TextView)findViewById(R.id.txtScore);
        questao = (TextView)findViewById(R.id.txtPergunta);

        btnResposta1 = (Button)findViewById(R.id.btnOpcao1);
        btnResposta2 = (Button)findViewById(R.id.btnOpcao2);
        btnResposta3 = (Button)findViewById(R.id.btnOpcao3);
        btnResposta4 = (Button)findViewById(R.id.btnOpcao4);

        nickname.setText(paramNome);
        score.setText("Score " + valorScore);
        /*------------------------------------------------------------------------------------------*/

        RequestQueue requestQueue = Volley.newRequestQueue(this);

        /*
        questao.setText(questaoUm());

        btnResposta1.setText("Jack");
        btnResposta2.setText("John");
        btnResposta3.setText("Frank");
        btnResposta4.setText("David");

        */

    JsonObjectRequest obreq = new com.android.volley.toolbox.JsonObjectRequest
            (
                    Request.Method.GET,
                    url,
                    null,
                    new Response.Listener<org.json.JSONObject>()
                    {
                        @Override
                        public void onResponse(JSONObject response)
                        {
                            try
                            {
                                // Pega o array "students"
                                JSONArray array = response.getJSONArray("questoes");

                                // Percorre o array
                                for(int i=0; i < array.length(); i++)
                                {
                                    // Pega o valor atual no array sendo percorrido
                                    JSONObject questoes = array.getJSONObject(i);

                                    // Pega os dados do estudante da posição atual do array
                                    quest = questoes.getString("questao");

                                    certa = questoes.getString("certa");
                                    errada1 = questoes.getString("errada1");
                                    errada2 = questoes.getString("errada2");
                                    errada3 = questoes.getString("errada3");

                                    // Exibe os dados

                                }
                                questao.setText(quest);

                                btnResposta1.setText(errada1);
                                btnResposta2.setText(certa);
                                btnResposta3.setText(errada2);
                                btnResposta4.setText(errada3);
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                    },
                    new Response.ErrorListener()
                    {
                        @Override
                        public void onErrorResponse(VolleyError error)
                        {
                            // Do something when error occurred
                        }
                    }
            );

        requestQueue.add(obreq);
    /*public void verificaResposta1(View v) { //onclick do botao 1
        Toast.makeText(this, "Resposta errada", Toast.LENGTH_LONG).show();
        btnResposta1.setBackgroundColor(getResources().getColor(R.color.Vermelho));
    }
    public void verificaResposta2(View v) { //onclick do botao 2
        Toast.makeText(this, "Resposta CERTA! " + btnResposta2.getText().toString(), Toast.LENGTH_LONG).show();
        valorScore +=10;
        score.setText("Score " + valorScore);
        btnResposta2.setBackgroundColor(getResources().getColor(R.color.colorAzulClaro));
    }
    public void verificaResposta3(View v) { //onclick do botao 3
        Toast.makeText(this, "Resposta errada", Toast.LENGTH_LONG).show();
        btnResposta3.setBackgroundColor(getResources().getColor(R.color.Vermelho));
    }
    public void verificaResposta4(View v) { //onclick do botao 4
        Toast.makeText(this, "Resposta errada", Toast.LENGTH_LONG).show();
        btnResposta4.setBackgroundColor(getResources().getColor(R.color.Vermelho));
    }

*/
}
}
